const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BBWR5ylF.js","assets/index-BObvS4SL.js","assets/index-COiAlOya.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BObvS4SL.js";const o=r("Share",{web:()=>t(()=>import("./web-BBWR5ylF.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

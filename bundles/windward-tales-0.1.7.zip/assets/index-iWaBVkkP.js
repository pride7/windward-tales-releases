const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Yajh24jp.js","assets/index-ClXoYsmo.js","assets/index-DWd93l-Z.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ClXoYsmo.js";const o=r("Share",{web:()=>t(()=>import("./web-Yajh24jp.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

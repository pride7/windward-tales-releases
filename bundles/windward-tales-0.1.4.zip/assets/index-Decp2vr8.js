const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BkCbIhdG.js","assets/index-1zjeX-Sx.js","assets/index-3rpyt4Xd.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-1zjeX-Sx.js";const o=r("Share",{web:()=>t(()=>import("./web-BkCbIhdG.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

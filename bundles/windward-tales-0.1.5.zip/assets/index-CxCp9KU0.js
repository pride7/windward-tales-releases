const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-pWAG3_nQ.js","assets/index-C5Z8scGN.js","assets/index-CiFEHK6-.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C5Z8scGN.js";const o=r("Share",{web:()=>t(()=>import("./web-pWAG3_nQ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

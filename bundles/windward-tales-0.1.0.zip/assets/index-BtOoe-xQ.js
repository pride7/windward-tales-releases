const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CaD2VEGI.js","assets/index-y6_epQLl.js","assets/index-COiAlOya.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-y6_epQLl.js";const o=r("Share",{web:()=>t(()=>import("./web-CaD2VEGI.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B0Zjmres.js","assets/index-zUP7uTzl.js","assets/index-C7myR9m7.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-zUP7uTzl.js";const o=r("Share",{web:()=>t(()=>import("./web-B0Zjmres.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

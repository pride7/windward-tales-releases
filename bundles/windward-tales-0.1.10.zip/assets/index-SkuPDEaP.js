const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Bqs9DBss.js","assets/index-xdYCkk-2.js","assets/index-CqfMt-6r.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-xdYCkk-2.js";const o=r("Share",{web:()=>t(()=>import("./web-Bqs9DBss.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-ddg5OVTA.js","assets/index-BJp0QXsH.js","assets/index-CqfMt-6r.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BJp0QXsH.js";const o=r("Share",{web:()=>t(()=>import("./web-ddg5OVTA.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

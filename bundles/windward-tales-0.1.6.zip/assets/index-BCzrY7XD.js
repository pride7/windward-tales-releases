const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BOOXuZcc.js","assets/index-CGm8bL-d.js","assets/index-CBzGvUPv.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CGm8bL-d.js";const o=r("Share",{web:()=>t(()=>import("./web-BOOXuZcc.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};

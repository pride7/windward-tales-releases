const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BK9dTGyI.js","assets/index-CduH79Px.js","assets/index-DlmUmnGO.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CduH79Px.js";const o=r("Share",{web:()=>t(()=>import("./web-BK9dTGyI.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
